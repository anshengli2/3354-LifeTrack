import java.util.Date;
public class displayDate 
{
	//uses the compareTo() function to compare two dates
	public int compareDates(Date d1, Date d2)
	{
		return d1.compareTo(d2);
	}
}